# Duplicate-Post-Finder
This plugin will search the WP database for all posts with "draft" status and list them next to published posts found to be similar in title or content.

## SERVER REQUIREMENTS
In our tests, a minimum of 512MB of server ram was needed to get everything working correctly.  Anything less caused errors.  